#include <iostream>
using namespace std;
int main (){
int i ;
for (var i  =1; i<21; i++){
            if(i%3===0 && i%2!==0){
                jawaban2 += i + ' - I Love Coding <br>'
            }else{
                if(i%2===0){
                    jawaban2 += i + ' - Berkualitas <br>'
                }else{
                    jawaban2 += i + ' - Santai <br>'
                }
            } 
        }