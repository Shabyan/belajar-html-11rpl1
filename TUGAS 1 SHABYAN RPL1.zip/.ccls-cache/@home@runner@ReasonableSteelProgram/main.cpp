#include <iostream>

using namespace std;

int main() {
  int a;
  for (a = 1; a <= 15; a++) {
    cout << "SMKN 1 SUBANG" << endl;
  }
}