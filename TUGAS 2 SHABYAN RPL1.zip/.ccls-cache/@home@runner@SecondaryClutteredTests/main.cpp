#include <iostream>
using namespace std;

int main(){
  int a;
  for(a=1;a<=5;a++){
    cout<<"RPL"<<a<<endl;
  }
}