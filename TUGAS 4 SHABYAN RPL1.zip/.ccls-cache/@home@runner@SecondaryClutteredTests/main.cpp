#include <iostream>
using namespace std;

int main(){
  int a;
  for(a=5;a>=1;a--){
    cout<<"RPL"<<a<<endl;
  }
}